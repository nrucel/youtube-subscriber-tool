-- MySQL dump 10.16  Distrib 10.2.19-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: tnrucelcom49_i
-- ------------------------------------------------------
-- Server version	10.2.19-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `uyeler`
--

DROP TABLE IF EXISTS `uyeler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uyeler` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `ytID` varchar(50) NOT NULL,
  `adSoyad` varchar(255) NOT NULL,
  `ytFoto` varchar(255) NOT NULL,
  `aboneSayisi` int(11) NOT NULL,
  `izlenmeSayisi` int(11) NOT NULL,
  `yorumSayisi` int(11) NOT NULL,
  `videoSayisi` int(11) NOT NULL,
  `aboneKredi` int(11) NOT NULL,
  `begeniKredi` int(11) NOT NULL,
  `sessID` varchar(12) NOT NULL,
  `ipAdres` varchar(50) NOT NULL,
  `referans` varchar(16) NOT NULL,
  `refSahip` int(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uyeler`
--

LOCK TABLES `uyeler` WRITE;
/*!40000 ALTER TABLE `uyeler` DISABLE KEYS */;
INSERT INTO `uyeler` (`id`, `ytID`, `adSoyad`, `ytFoto`, `aboneSayisi`, `izlenmeSayisi`, `yorumSayisi`, `videoSayisi`, `aboneKredi`, `begeniKredi`, `sessID`, `ipAdres`, `referans`, `refSahip`) VALUES (4,'UCP6ZMJ_RNPpsAZvvPYv6DEQ','Web Hazne','https://yt3.ggpht.com/a-/AN66SAwZ0gN8rEMzQRvjKEbYSWw4aV9U0Jrn7-VQYQ=s88-mo-c-c0xffffffff-rj-k-no',236,346,0,1,11,30,'9491544659','217.131.200.69','bf5ae80b0abce7a2',3),(3,'UCx9Ec9Gmx_IlZeJha-moOuQ','haktan uyar','https://yt3.ggpht.com/a-/AN66SAyk8nq7J5Roj1ru3P50rpVj8I5WHwTXuEV7Tg=s88-mo-c-c0xffffffff-rj-k-no',170,159,0,2,39,30,'1683156016','88.245.161.241','WdsdaEWd54',0);
/*!40000 ALTER TABLE `uyeler` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vipler`
--

DROP TABLE IF EXISTS `vipler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vipler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adSoyad` varchar(100) NOT NULL,
  `sifre` varchar(30) NOT NULL,
  `email` varchar(250) NOT NULL,
  `yetkili` tinyint(1) NOT NULL DEFAULT 0,
  `kayitTarihi` timestamp NOT NULL DEFAULT current_timestamp(),
  `vipeNot` text NOT NULL,
  `sessID` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vipler`
--

LOCK TABLES `vipler` WRITE;
/*!40000 ALTER TABLE `vipler` DISABLE KEYS */;
INSERT INTO `vipler` (`id`, `adSoyad`, `sifre`, `email`, `yetkili`, `kayitTarihi`, `vipeNot`, `sessID`) VALUES (4,'Nurullah Çelik','nrcl','nurullahcelik@yandex.com',1,'2017-06-05 21:00:00','','{\"1544918831\":8097165594808}');
/*!40000 ALTER TABLE `vipler` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'tnrucelcom49_i'
--

--
-- Dumping routines for database 'tnrucelcom49_i'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-17  4:37:18
